#!/usr/bin/env python3

with open("pig_dice_rules.txt") as file:
    print(file.read())
print()
