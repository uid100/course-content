SELECT *
FROM Movie
WHERE categoryID = 3
