DELETE FROM Movie 
WHERE movieID = 14
