class DataAccessError(Exception):
    pass
